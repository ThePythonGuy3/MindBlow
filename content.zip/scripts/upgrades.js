const cap1 = extendContent(Block, "capup-1", {
	setStats(){},
	canPlaceOn(){return false},
	isHidden(){return true}
});
const cap2 = extendContent(Block, "capup-2", {
	setStats(){},
	canPlaceOn(){return false},
	isHidden(){return true}
});
const cap3 = extendContent(Block, "capup-3", {
	setStats(){},
	canPlaceOn(){return false},
	isHidden(){return true}
});
const unp = extendContent(Block, "unitup", {
	setStats(){},
	canPlaceOn(){return false},
	isHidden(){return true}
});