# MindBlow

Adds a vanilla expansion to mindustry. It adds multiple drills, turrets, resources, and some units. 
*Still in development*

> **ThePythonGuy.**

> Thanks to **GlennFolker** and **JerichoFletcher** for various libraries

> Thanks to **sk7725** for making the ui health circle

> Thanks to **SteelBlue8** and **GrimSoul** for various sprites!

> Thanks to **Txar** for spriting and ideas!

> Thanks to **EyeOfDarkness** for item score library!

If you think its worth it, star this repository :D
